# Design System Document: Academic Sophistication

## 1. Overview & Creative North Star: "The Digital Curator"
This design system moves away from the cluttered, utilitarian nature of traditional academic portals. Our Creative North Star is **The Digital Curator**. We treat information not as "data to be managed," but as "content to be showcased." 

To achieve this, we break the "template" look through **Intentional Asymmetry** and **Editorial Breathing Room**. By utilizing extreme whitespace and a rigid typographic hierarchy, we create an environment of focus and intellectual clarity. The interface should feel like a premium digital journal—authoritative, quiet, and deeply intentional.

---

## 2. Colors: Tonal Depth & The "No-Line" Rule
The palette is rooted in a professional Navy (`primary`) and a sophisticated Light Gray (`surface`). However, the soul of the system lies in how these tones transition.

### The "No-Line" Rule
Standard 1px borders are prohibited for sectioning. We define boundaries through **Background Color Shifts**. 
*   **The Transition:** Use a `surface-container-low` section sitting directly on a `surface` background to define a sidebar or a header. 
*   **The Edge:** Contrast is achieved via value changes, not strokes. This ensures the UI feels like a single, cohesive canvas rather than a collection of boxes.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Use the Material tiers to create "nested" importance:
1.  **Base Layer:** `surface` (#f8fafb) – The canvas.
2.  **Structural Zones:** `surface-container-low` (#f0f4f6) – For sidebars or utility zones.
3.  **Actionable Content:** `surface-container-lowest` (#ffffff) – Used for primary cards or content pieces to make them "pop" against the slightly darker base.

### The "Glass & Gradient" Rule
To prevent the "flat" look of generic minimalism:
*   **Signature Gradients:** For primary CTAs, utilize a subtle linear gradient from `primary` (#3a5f94) to `primary_dim` (#2d5387). This adds a "weighted" feel to the navy elements.
*   **Glassmorphism:** For floating navigation or modal overlays, use `surface` with 80% opacity and a `24px` backdrop-blur. This allows the university's content to bleed through softly, maintaining context.

---

## 3. Typography: The Editorial Voice
We use **Inter** as our sole typeface, relying on extreme scale and weight contrast to drive the narrative.

*   **Display Scale (`display-lg` to `display-sm`):** Reserved for high-level dashboard welcomes or major research headers. These should be set with tight tracking (-0.02em) to feel like a premium masthead.
*   **Headline & Title:** Use `headline-sm` for section titles. Pair these with ample top-margin to signal a transition in thought.
*   **The Body:** `body-md` is our workhorse. We prioritize legibility by maintaining a line height of 1.5x for all collaborative text blocks.
*   **Labels:** `label-sm` should always be uppercase with +0.05em letter spacing when used for metadata, reinforcing the "curated" aesthetic.

---

## 4. Elevation & Depth: Tonal Layering
We reject traditional shadows in favor of **Tonal Layering**.

*   **The Layering Principle:** Depth is achieved by "stacking." A `surface-container-lowest` card placed on a `surface-container` background creates a natural lift.
*   **Ambient Shadows:** If a floating element (like a FAB or Dropdown) requires a shadow, it must use a `12%` opacity of the `on_surface` color with a `32px` blur and `16px` Y-offset. It should feel like a soft glow, not a hard drop.
*   **The "Ghost Border" Fallback:** In high-density data views where borders are legally or functionally required, use a "Ghost Border": `outline_variant` at **15% opacity**. Never use a 100% opaque border.

---

## 5. Components: Minimalist Primitives

### Buttons
*   **Primary:** Solid `primary` fill, `on_primary` text. `xl` roundedness (0.75rem). No shadow.
*   **Secondary:** `surface-container-high` fill. Feels integrated into the page.
*   **Tertiary:** Ghost style. No background, `primary` text. Only a subtle `surface-hover` on interaction.

### Cards & Lists
*   **Rule:** Forbid divider lines. 
*   **Separation:** Use `32px` of vertical whitespace between list items. For cards, use the "Surface Hierarchy" (white card on a gray background) to define the container.
*   **Interaction:** On hover, a card should shift from `surface-container-lowest` to a subtle `primary_container` tint (at 5% opacity).

### Input Fields
*   **Style:** Underline-only or Ghost-style. Avoid the "boxed" input. 
*   **States:** On focus, the `outline` transforms into a `2px` `primary` bottom bar. This mimics the act of writing on a lined paper.

### Academic-Specific Components
*   **Collaboration Chips:** Use `secondary_container` for group tags. They should be "pill" shaped (`full` roundedness) to contrast against the sharp, rectangular layout of the content.
*   **Status Indicators:** Use `tertiary` for "In Progress" states—a sophisticated muted purple that sits elegantly between the Navy and Gray.

---

## 6. Do's and Don'ts

### Do:
*   **DO** use "Negative Space" as a functional element. If a screen feels crowded, increase the padding, don't shrink the text.
*   **DO** use `surface-tint` for subtle brand moments (e.g., a 2px top-bar on a featured card).
*   **DO** ensure all touch targets are at least 44px, even if the visual element (like a text link) is smaller.

### Don't:
*   **DON'T** use pure black (#000). Always use `on_surface` (#2a3437) for text to maintain a professional, soft-contrast look.
*   **DON'T** use heavy drop shadows or 3D effects. The system is intentionally "Flat-Plus."
*   **DON'T** crowd the edges. Maintain a minimum global page margin of `48px` on desktop and `24px` on mobile.