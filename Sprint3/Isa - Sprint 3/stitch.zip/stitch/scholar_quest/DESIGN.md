# Design System Document: Academic Playground

## 1. Overview & Creative North Star: "The Collaborative Campus"
This design system moves away from the sterile, rigid structures of traditional academic software. Our Creative North Star is **"The Collaborative Campus"**—an environment that feels like a vibrant, sun-drenched courtyard where ideas intersect. 

Instead of a "productivity tool," the UI functions as a rewarding ecosystem. We break the standard "dashboard" mold by utilizing **intentional asymmetry**, **exaggerated organic curves**, and **layered depth**. We treat the interface not as a flat screen, but as a physical space where cards "float" over a warm, tactile base, and progress is celebrated with illustrative flair rather than just data points.

---

## 2. Colors: Tonal Depth & Vibrancy
Our palette is anchored in warm, sun-soaked neutrals (`surface`) and punctuated by high-energy primaries. 

### The "No-Line" Rule
**Prohibit 1px solid borders for sectioning.** Boundaries are defined strictly through background shifts. A `surface-container-low` section sitting on a `surface` background provides all the separation necessary. We rely on the contrast between `#fff6e1` (background) and `#ffe796` (container) to guide the eye.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. 
*   **Base:** `surface` (#fff6e1)
*   **Sub-sections:** `surface-container-low` (#fff0c4)
*   **Interactive Cards:** `surface-container` (#ffe796)
*   **Active/Pop-out Elements:** `surface-container-highest` (#f5dc81)

### The "Glass & Gradient" Rule
For floating elements like notifications or mobile navigation docks, use **Glassmorphism**. Apply `surface-container-lowest` at 80% opacity with a `24px` backdrop blur. 
*   **Signature Textures:** Use subtle linear gradients for primary buttons and progress bars (e.g., `primary` #7b5400 to `primary-container` #feb300). This adds "soul" and prevents the gamified elements from looking like flat clip-art.

---

## 3. Typography: Editorial Playfulness
We pair a high-character display face with a highly legible, modern body face to balance "University Authority" with "Student Energy."

*   **Display & Headlines (Plus Jakarta Sans):** Our "Voice." Used for headers and achievement callouts. The generous x-height and open counters feel friendly and modern.
    *   *Display-LG (3.5rem):* Reserved for major milestones or "Quest" titles.
    *   *Headline-MD (1.75rem):* For primary section headers.
*   **Titles & Body (Be Vietnam Pro):** Our "Function." A geometric sans that maintains clarity even in dense collaboration threads.
    *   *Title-MD (1.125rem):* For card headers and navigation.
    *   *Body-LG (1rem):* Standard reading size for collaborative posts.
    *   *Label-MD (0.75rem):* For metadata and gamified stats (XP, Level).

---

## 4. Elevation & Depth: Tonal Layering
Depth is a functional tool for hierarchy, not just decoration.

*   **The Layering Principle:** Stack surfaces. A `surface-container-lowest` (#ffffff) card placed on a `surface-container-low` (#fff0c4) background creates a "natural lift" that signals interactivity without a single line of CSS border.
*   **Ambient Shadows:** For "Floating" action buttons or active badge containers, use ultra-diffused shadows.
    *   *Shadow Specs:* `0px 12px 32px rgba(57, 46, 0, 0.06)`. Note the use of `on-surface` (#392e00) as the shadow tint rather than pure black—this maintains the warmth of the palette.
*   **The Ghost Border:** If a border is required for accessibility (e.g., input fields), use `outline-variant` (#bfac6c) at **20% opacity**.

---

## 5. Components: Gamified Primitives

### Buttons & CTAs
*   **Primary:** Uses a gradient from `primary` to `primary-dim`. Corner radius: `full` (pill-shaped). High-elevation shadow on hover.
*   **Secondary:** `secondary-container` (#97daff) with `on-secondary-container` text. No shadow; feels "embedded" in the page.

### Badge Containers (Gamification)
*   Use `lg` (2rem) or `xl` (3rem) corner radius.
*   Badges should always be paired with `tertiary` (#a7295a) accents to signify "Reward" or "Special Status."

### Progress Bars
*   **Track:** `surface-container-highest`.
*   **Indicator:** A gradient of `primary` to `primary-container`.
*   **Animation:** Use a slight "bounce" (cubic-bezier) when the bar fills to reinforce the playful aesthetic.

### Cards & Lists
*   **Forbid dividers.** Use `1.5rem` to `2rem` of vertical white space to separate list items.
*   **Active State:** When a card is selected, transition the background to `surface-bright` and increase the ambient shadow.

### Input Fields
*   Background: `surface-container-lowest`.
*   Border: None. Use a 2px bottom-stroke of `primary` only when the field is focused.

---

## 6. Do’s and Don’ts

### Do
*   **Do** use asymmetrical layouts for "Quest" or "Achievement" screens to make them feel special.
*   **Do** use illustrative icons (rounded, thick strokes) in `secondary` or `tertiary` colors.
*   **Do** embrace white space. This system requires "air" to prevent the bright colors from feeling overwhelming.
*   **Do** use `9999px` (full) rounding for small UI tags to make them feel like "tokens" or "chips."

### Don't
*   **Don't** use 100% black (#000000) anywhere. Even for text, use `on-surface` (#392e00).
*   **Don't** use sharp corners. The smallest radius allowed is `sm` (0.5rem) for tiny utility components.
*   **Don't** use "Drop Shadows" that are dark and tight. Always go for large, soft, tinted ambient glows.
*   **Don't** use standard "system" dividers. If a visual break is needed, use a subtle shift from `surface` to `surface-variant`.