# Design System Specification: The Kinetic Campus

## 1. Overview & Creative North Star
This design system is built to transform the PUC-CTC collaborative experience from a static utility into a high-energy digital ecosystem. We move away from the "standard portal" aesthetic by embracing **The Kinetic Campus**—a creative North Star that treats the UI as a living, breathing terminal of information. 

The aesthetic is rooted in **Neo-Tech Editorial**. We reject rigid grids and thin structural lines in favor of intentional asymmetry, overlapping translucent layers, and high-contrast typography. By leveraging massive border radii and glassmorphism, we create an environment that feels both sophisticated and approachable, mirroring the fluid nature of modern academic collaboration.

## 2. Colors & Surface Philosophy
The palette is centered on deep, cosmic violets and electric cyan accents. Color is not just decorative; it is the primary driver of hierarchy and depth.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections or containers. Physical boundaries must be established through:
1.  **Background Tonal Shifts:** Placing a `surface_container_low` card on a `surface` background.
2.  **Luminous Depth:** Using `surface_bright` to highlight active zones.
3.  **Soft Transitions:** Utilizing subtle background-color shifts to indicate "new sections."

### Surface Hierarchy & Nesting
Treat the UI as a series of physical, stacked sheets of frosted tech-glass. 
- **Base Level:** `surface` (#16052a).
- **Navigation/Lateral Zones:** `surface_container_low` (#1c0832).
- **Primary Content Cards:** `surface_container` (#240e3b).
- **Interactive/Floating Modals:** `surface_container_highest` (#32194e).

### The "Glass & Gradient" Rule
To achieve the "Tech" aesthetic, use Glassmorphism for floating elements (e.g., sidebars, popovers). 
- **Glass Spec:** `surface_variant` (#32194e) at 60% opacity with a `20px` to `40px` backdrop-blur.
- **Vibrant Pulses:** Use gradients transitioning from `primary` (#b89fff) to `secondary` (#00e3fd) for hero CTAs and dynamic progress indicators. This injects "soul" into the dark interface.

## 3. Typography
The typography system uses a high-contrast pairing to balance technical precision with editorial authority.

*   **Display & Headlines (Space Grotesk):** This is our "Tech" voice. Use `display-lg` (3.5rem) for landing headers and `headline-lg` (2rem) for major module titles. The wide, geometric nature of Space Grotesk demands breathing room—do not crowd these headers.
*   **Body & Titles (Manrope):** Our "Human" voice. Manrope provides exceptional legibility for dense collaborative threads. Use `body-lg` (1rem) for primary reading and `title-md` (1.125rem) for card headings.
*   **Intentional Scale:** We utilize a "Bigger is Better" approach for headers to create a dynamic sense of energy. If a header feels "standard," it’s too small.

## 4. Elevation & Depth
Depth is achieved through **Tonal Layering** rather than traditional structural lines or heavy shadows.

*   **The Layering Principle:** Stacking is the new bordering. An inner card (`surface_container_high`) sitting on a section (`surface_container_low`) creates a soft, natural lift.
*   **Ambient Shadows:** If an element must float (like a FAB or a dropdown), use a shadow tinted with `surface_tint`. 
    *   *Spec:* `0px 20px 40px rgba(184, 159, 255, 0.08)`. Never use pure black or grey shadows.
*   **The "Ghost Border" Fallback:** If accessibility requirements demand a container edge, use a Ghost Border. This is the `outline_variant` (#524067) token at **15% opacity**. It should be felt, not seen.
*   **Corner Radii:** We embrace the "Super-Ellipse."
    *   `lg`: 2rem (Default for main content cards).
    *   `xl`: 3rem (Hero sections and large containers).
    *   `full`: 9999px (Buttons and Tags).

## 5. Components

### Buttons
*   **Primary:** Solid `primary` (#b89fff) with `on_primary` (#37008e) text. Roundedness: `full`.
*   **Secondary (Tech-Vibe):** A glassmorphic button using `surface_variant` with a 1px "Ghost Border" at 20% opacity. 
*   **States:** On hover, primary buttons should "glow" by increasing the shadow spread of the `primary_dim` color.

### Chips & Tags
*   Use `secondary_container` (#006875) with `on_secondary_container` (#e8fbff) for active status. 
*   Corners must always be `full`. No square tags.

### Input Fields
*   Background: `surface_container_highest` (#32194e).
*   Shape: `md` (1.5rem) radius.
*   No borders on resting state. On focus, use a `secondary` (#00e3fd) "Ghost Border" (20% opacity) and a subtle inner glow.

### Cards & Lists
*   **Prohibition:** Dividers are banned. 
*   **The Separation Rule:** Separate list items using `12px` of vertical whitespace or a subtle background shift (alternating `surface_container` and `surface_container_low`).
*   **Cards:** Must use `lg` (2rem) corner radius. Use `surface_variant` with backdrop blur for cards that overlay imagery.

### Context-Specific: "The Collaboration Hub"
*   **Activity Orbs:** Use `tertiary` (#ff59e3) for notification badges. The high contrast against the purple/blue background ensures instant visual priority.

## 6. Do's and Don'ts

### Do
*   **Embrace Negative Space:** Give headers room to breathe. High energy comes from the contrast between bold type and open space.
*   **Use Asymmetry:** Place a large `display-sm` header on the left with a smaller `body-md` description offset to the right.
*   **Layer Transitions:** When moving between light and dark modes, ensure the surface tiers (Lowest to Highest) maintain their relative contrast ratios.

### Don't
*   **Don't use 1px Dividers:** This is the quickest way to make the app look like a legacy template.
*   **Don't use Grey:** Every "neutral" in this system is tinted with violet or blue. Pure greys (#888888) are forbidden; use `on_surface_variant` (#b9a2d0) instead.
*   **Don't use Sharp Corners:** Even "small" components (like checkboxes) should have a slight radius. The aesthetic is fluid, not jagged.